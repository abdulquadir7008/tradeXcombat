<?php

namespace App\Http\Controllers\RestApi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
   public function register(Request $request)
{
    $validated = $request->validate([
        'name' => 'required|string',
        'email' => 'required|email|unique:users',
        'password' => 'required|confirmed|min:6'
    ]);

    $user = User::create([
        'name' => $validated['name'],
        'email' => $validated['email'],
        'password' => Hash::make($validated['password'])
    ]);

    // issue token using api guard
    $token = auth('api')->login($user);

    DB::table('user_tokens')->insert([
        'user_id'    => $user->id,
        'token'      => $token,
        'created_at' => now()
    ]);

    return response()->json([
        'message' => 'registered successfully',
        'status' => true,
        'Response' => [
            'access_token' => $token,
            'token_type'   => 'bearer',
            'expires_in'   => auth('api')->factory()->getTTL() * 60,
            'id'           => $user->id,
            'email'        => $user->email,
        ]
    ]);
}

  protected function respondWithToken($token)
{
    $user = auth('api')->user();

    return response()->json([
        'message' => 'loginned successfully',
        'Status' => true,
        'Response' => [
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            'id' => $user->id,
            'email' => $user->email,
        ],
    ]);
}

    public function changePassword(Request $request){
            $user = auth('api')->user();
            $request->validate([
                'current_password' => 'required',
                'new_password' => 'required|min:6|confirmed',
            ]);
            if (!Hash::check($request->current_password, $user->password)) {
                return response()->json([
                    'message' => 'Current password is incorrect.'
                ], 401);
            }
            $user->password = Hash::make($request->new_password);
            $user->save();
            return response()->json([
                'status' => true,
                'message' => 'Password changed successfully.'
            ], 200);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
        if (!$token = auth('api')->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        DB::table('login_logs')->insert([
            'user_id'       => auth('api')->id(),
            'token'         => $token,
            'ip_address'    => $request->ip(),
            'user_agent'    => $request->header('User-Agent'),
            'logged_in_at'  => now(),
            'created_at'    => now(),
            'updated_at'    => now()
        ]);
        return $this->respondWithToken($token);
    }

    public function logout()
    {
        $token = JWTAuth::getToken();
        auth()->logout();
        DB::table('login_logs')
            ->where('token', $token)
            ->update([
                'logged_out_at' => now(),
                'updated_at'    => now()
            ]);
        return response()->json([
            'status' => true,
            'message' => 'Successfully logged out']);
    }
}

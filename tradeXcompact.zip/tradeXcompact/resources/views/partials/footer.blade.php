<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-6">
				<script>document.write(new Date().getFullYear())</script> © TradeXcombat.
			</div>
			<div class="col-sm-6">
				<div class="text-sm-end d-none d-sm-block">
					Design & Develop by <a href="https://www.bridgingfx.net/" target="_blank">Bridgingfx</a>
				</div>
			</div>
		</div>
	</div>
</footer>
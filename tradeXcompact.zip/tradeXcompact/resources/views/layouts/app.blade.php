<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-layout="vertical" data-topbar="dark" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-bs-theme="dark" data-layout-width="fluid" data-layout-position="fixed" data-layout-style="default">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts - ->
    @vite(['resources/sass/app.scss', 'resources/js/app.js']) -->
	
	<!-- jsvectormap css -->
	<link href="{{ asset('assets/libs/jsvectormap/jsvectormap.min.css') }}" rel="stylesheet" type="text/css" />

	<!--Swiper slider css-->
	<link href="{{ asset('assets/libs/swiper/swiper-bundle.min.css') }}" rel="stylesheet" type="text/css" />

	<!-- Layout config Js -->
	<script src="{{ asset('assets/js/layout.js') }}"></script>
	<!-- Bootstrap Css -->
	<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
	<!-- Icons Css -->
	<link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
	<!-- App Css-->
	<link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" />
	<!-- custom Css-->
	<link href="{{ asset('assets/css/custom.min.css') }}" rel="stylesheet" type="text/css" />
	
	
</head>
<body>
    <div id="app">
        <main class="py-4">
            @yield('content')
        </main>
    </div>
	
	<!-- JAVASCRIPT -->
	<script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
	<script src="{{ asset('assets/libs/simplebar/simplebar.min.js') }}"></script>
	<script src="{{ asset('assets/js/pages/plugins/lord-icon-2.1.0.js') }}"></script>
	<script src="{{ asset('assets/js/plugins.js') }}"></script>

	<!-- apexcharts -->
	<script src="{{ asset('assets/libs/apexcharts/apexcharts.min.js') }}"></script>

	<!-- Vector map-->
	<script src="{{ asset('assets/libs/jsvectormap/jsvectormap.min.js') }}"></script>
	<script src="{{ asset('assets/libs/jsvectormap/maps/world-merc.js') }}"></script>

	<!--Swiper slider js-->
	<script src="{{ asset('assets/libs/swiper/swiper-bundle.min.js') }}"></script>

	<!-- Dashboard init -->
	<script src="{{ asset('assets/js/pages/dashboard-ecommerce.init.js') }}"></script>

	<!-- App js -->
	<script src="{{ asset('assets/js/app.js') }}"></script>
	<script src="{{ asset('assets/js/pages/password-addon.init.js') }}"></script>
	
	<!-- validation init -->
	<script src="{{ asset('assets/js/pages/form-validation.init.js') }}"></script>
	<!-- password create init -->
	<script src="{{ asset('assets/js/pages/passowrd-create.init.js') }}"></script>
	
	    <!-- apexcharts -->
    <script src="{{ asset('assets/libs/apexcharts/apexcharts.min.js') }}"></script>

    <!-- piecharts init -->
    <script src="{{ asset('assets/js/pages/apexcharts-pie.init.js') }}"></script>
	
</body>
</html>

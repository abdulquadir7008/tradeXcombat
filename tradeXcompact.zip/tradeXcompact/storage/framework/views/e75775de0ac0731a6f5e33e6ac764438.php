<!-- ========== App Menu ========== -->
		<div class="app-menu navbar-menu">
			<!-- LOGO -->
			<div class="navbar-brand-box">
				<a href="<?php echo e(route('home')); ?>" class="logo logo-dark">
					<span class="logo-sm">
						<img src="<?php echo e(asset('public/assets/images/logo-sm.png')); ?>" alt="" height="26">
					</span>
					<span class="logo-lg">
						<img src="<?php echo e(asset('public/assets/images/Logo-2.png')); ?>" alt="" height="26">
					</span>
				</a>
				<a href="<?php echo e(route('home')); ?>" class="logo logo-light">
					<span class="logo-sm">
						<img src="<?php echo e(asset('public/assets/images/logo-sm.png')); ?>" alt="" height="26">
					</span>
					<span class="logo-lg">
						<img src="<?php echo e(asset('public/assets/images/Logo-2.png')); ?>" alt="" height="26">
					</span>
				</a>
				<button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
					<i class="ri-record-circle-line"></i>
				</button>
			</div>

			<div id="scrollbar">
				<div class="container-fluid">

					<div id="two-column-menu">
					</div>
					<ul class="navbar-nav" id="navbar-nav">
		
						<li class="menu-title"><span data-key="t-menu">Overview</span></li>
						<li class="nav-item">
							<a href="<?php echo e(route('home')); ?>" class="nav-link menu-link"> <i class="bi bi-speedometer2"></i> <span data-key="t-dashboard">Dashboard</span> </a>
						</li>

						<li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">User Management</span></li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Player List</span> </a>
						</li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Refer and Earn</span> </a>
						</li>
						
						<li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">Battle Management</span></li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Combats Match</span> </a>
						</li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Loyalties</span> </a>
						</li>
						
						<li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">Finance Management</span></li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Transaction</span> </a>
						</li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Pending Transaction</span> </a>
						</li>
						
						<li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">Content Management</span></li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Currency List</span> </a>
						</li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">News And Tutorials</span> </a>
						</li>
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">Events And Promotion</span> </a>
						</li>
						
						<li class="menu-title"><i class="ri-more-fill"></i> <span data-key="t-pages">System Settings</span></li>
						<li class="nav-item">
							<a class="nav-link menu-link" href="#sidebarPages" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarPages">
								<i class="bi bi-journal-medical"></i> <span data-key="t-pages">Staff Management</span>
							</a>
							<div class="collapse menu-dropdown" id="sidebarPages">
								<ul class="nav nav-sm flex-column">
									<li class="nav-item">
										<a href="pages-starter.html" class="nav-link" data-key="t-starter"> Starter </a>
									</li>
								</ul>
							</div>
						</li>
						
						<li class="nav-item">
							<a href="index.html" class="nav-link menu-link"> <i class="bi bi-person-circle"></i> <span data-key="t-dashboard">App Configuration</span> </a>
						</li>
						<li class="nav-item">
							<a class="nav-link menu-link" href="#sidebarPages" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarPages">
								<i class="bi bi-journal-medical"></i> <span data-key="t-pages">Support</span>
							</a>
							<div class="collapse menu-dropdown" id="sidebarPages">
								<ul class="nav nav-sm flex-column">
									<li class="nav-item">
										<a href="pages-starter.html" class="nav-link" data-key="t-starter"> Starter </a>
									</li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
				<!-- Sidebar -->
			</div>

			<div class="sidebar-background"></div>
		</div>
		<!-- Left Sidebar End -->
		<!-- Vertical Overlay-->
		<div class="vertical-overlay"></div><?php /**PATH C:\BridgingFX\Rajkumar\tradeXcompact\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>
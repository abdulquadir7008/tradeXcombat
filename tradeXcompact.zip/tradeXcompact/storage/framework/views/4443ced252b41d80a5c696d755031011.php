<div class="row">
                                        

                                        <div class="col-xl-12">
                                            <div class="card">
                                                <div class="card-header align-items-center d-flex">
                                                    <h4 class="card-title mb-0 flex-grow-1">Recently Added Players</h4>
                                                    <div class="flex-shrink-0">
                                                        
														<div class="dropdown card-header-dropdown">
                                                            <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <span class="fw-semibold text-uppercase fs-12">Sort by:
                                                                </span><span class="text-muted">Today<i class="mdi mdi-chevron-down ms-1"></i></span>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a class="dropdown-item" href="#">Today</a>
                                                                <a class="dropdown-item" href="#">Yesterday</a>
                                                                <a class="dropdown-item" href="#">Last 7 Days</a>
                                                                <a class="dropdown-item" href="#">Last 30 Days</a>
                                                                <a class="dropdown-item" href="#">This Month</a>
                                                                <a class="dropdown-item" href="#">Last Month</a>
                                                            </div>
                                                        </div>
														
                                                    </div>
													<a href="javascript:void(0);" class="flex-shrink-0 ml-1">Manage Players <i class="ri-arrow-right-line align-bottom ms-1"></i></a>
                                                </div><!-- end card header -->
                                            
                                                <div class="card-body">
                                                    <div class="table-responsive table-card">
                                                        <table class="table table-centered align-middle table-nowrap mb-0">
                                                            <thead class="table-light">
                                                                <tr>
                                                                    <th scope="col">Purchase ID</th>
                                                                    <th scope="col">Customer Name</th>
                                                                    <th scope="col">Product Name</th>
                                                                    <th scope="col">Amount</th>
                                                                    <th scope="col">OrderDate</th>
                                                                    <th scope="col">Vendor</th>
                                                                    <th scope="col">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010331</a>
                                                                    </td>
                                                                    <td>
                                                                        Macbook Pro
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-2.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Terry White</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $658.00
                                                                    </td>
                                                                    <td>28 Oct, 2022</td>
                                                                    <td>Brazil</td>
                                                                    <td>
                                                                        <span class="badge text-success  bg-success-subtle">Paid</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010332</a>
                                                                    </td>
                                                                    <td>
                                                                        Borosil Paper Cup
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-4.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Daniel Gonzalez</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $345.00
                                                                    </td>
                                                                    <td>29 Oct, 2022</td>
                                                                    <td>Namibia</td>
                                                                    <td>
                                                                        <span class="badge text-danger  bg-danger-subtle">Unpaid</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010333</a>
                                                                    </td>
                                                                    <td>
                                                                        Stillbird Helmet
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-3.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Stephen Bird</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $80.00
                                                                    </td>
                                                                    <td>30 Oct, 2022</td>
                                                                    <td>USA</td>
                                                                    <td>
                                                                        <span class="badge text-success  bg-success-subtle">Paid</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010334</a>
                                                                    </td>
                                                                    <td>
                                                                        Bentwood Chair
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-10.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Ashley Silva</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $349.99
                                                                    </td>
                                                                    <td>31 Oct, 2022</td>
                                                                    <td>Argentina</td>
                                                                    <td>
                                                                        <span class="badge text-warning bg-warning-subtle">Pending</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010335</a>
                                                                    </td>
                                                                    <td>
                                                                        Apple Headphone
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-9.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Scott Wilson</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $264.37
                                                                    </td>
                                                                    <td>01 Nov, 2022</td>
                                                                    <td>Jersey</td>
                                                                    <td>
                                                                        <span class="badge text-danger  bg-danger-subtle">Unpaid</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                                <tr>
                                                                    <td>
                                                                        <a href="#!" class="fw-medium link-primary">#TB010336</a>
                                                                    </td>
                                                                    <td>
                                                                        Smart Watch for Man's
                                                                    </td>
                                                                    <td>
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="flex-shrink-0 me-2">
                                                                                <img src="assets/images/users/avatar-8.jpg" alt="" class="avatar-xs rounded-circle" />
                                                                            </div>
                                                                            <div class="flex-grow-1">Heather Jimenez</div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        $741.98
                                                                    </td>
                                                                    <td>02 Nov, 2022</td>
                                                                    <td>Spain</td>
                                                                    <td>
                                                                        <span class="badge text-success  bg-success-subtle">Paid</span>
                                                                    </td>
                                                                </tr><!-- end tr -->
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="row align-items-center mt-4 pt-2 gy-2 text-center text-sm-start">
                                                        <div class="col-sm">
                                                            <div class="text-muted">
                                                                Showing <span class="fw-semibold">6</span> of <span class="fw-semibold">25</span> Results
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-auto">
                                                            <ul class="pagination pagination-separated pagination-sm mb-0 justify-content-center justify-content-sm-start">
                                                            <li class="page-item disabled">
                                                                <a href="#" class="page-link">←</a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link">1</a>
                                                            </li>
                                                            <li class="page-item active">
                                                                <a href="#" class="page-link">2</a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link">3</a>
                                                            </li>
                                                            <li class="page-item">
                                                                <a href="#" class="page-link">→</a>
                                                            </li>
                                                        </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div><?php /**PATH C:\BridgingFX\Rajkumar\tradeXcompact\resources\views/partials/recentpendingdeposit.blade.php ENDPATH**/ ?>